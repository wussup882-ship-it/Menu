# Classic Menu (Quest app launcher)

A simple app launcher panel: Apps / Favorites / Recent tabs, search, and a pinned-apps dock at the bottom.
It runs as a normal app (it does not replace the Quest system menu).

1. Create a new GitHub repo and upload all of these files (keep the folder structure, including `.github/workflows/build.yml`).
2. Open the repo's Actions tab -> "Build APK" -> wait for the green check.
3. Open the finished run -> Artifacts -> download ClassicMenu-apk (zip) -> unzip to get app-debug.apk.
4. Install on the headset with Meta Quest Developer Hub, SideQuest, or `adb install app-debug.apk` (Developer Mode required).
5. On the headset: Library -> filter "Unknown Sources" -> Classic Menu.
