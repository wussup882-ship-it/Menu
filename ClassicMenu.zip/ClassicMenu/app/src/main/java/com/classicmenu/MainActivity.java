package com.classicmenu;

import android.app.Activity;
import android.content.ComponentName;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.EditText;
import android.widget.GridView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

public class MainActivity extends Activity {

    static class App {
        String label;
        String pkg;
        ComponentName cn;
        Drawable icon;
    }

    private static final String[] TAB_KEYS = {"all", "fav", "recent"};
    private static final String[] TAB_NAMES = {"Apps", "Favorites", "Recent"};
    private static final String VR_CATEGORY = "com.oculus.intent.category.VR";

    private final List<App> all = new ArrayList<>();
    private final Map<String, App> byPkg = new HashMap<>();
    private final List<App> shown = new ArrayList<>();
    private final TextView[] tabViews = new TextView[3];

    private SharedPreferences prefs;
    private BaseAdapter adapter;
    private LinearLayout dock;
    private String tab = "all";
    private String query = "";

    private int dp(int v) {
        return Math.round(v * getResources().getDisplayMetrics().density);
    }

    private GradientDrawable rounded(int color, int radiusDp) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(color);
        g.setCornerRadius(dp(radiusDp));
        return g;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        prefs = getSharedPreferences("menu", MODE_PRIVATE);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(Color.parseColor("#15171D"));
        root.setPadding(dp(24), dp(16), dp(24), dp(16));

        // Header: tabs on the left, search on the right
        LinearLayout header = new LinearLayout(this);
        header.setOrientation(LinearLayout.HORIZONTAL);
        header.setGravity(Gravity.CENTER_VERTICAL);
        for (int i = 0; i < 3; i++) {
            final String key = TAB_KEYS[i];
            TextView t = new TextView(this);
            t.setText(TAB_NAMES[i]);
            t.setTextSize(18);
            t.setTypeface(Typeface.DEFAULT_BOLD);
            t.setPadding(dp(18), dp(8), dp(18), dp(8));
            t.setOnClickListener(v -> {
                tab = key;
                refresh();
            });
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
            lp.rightMargin = dp(8);
            header.addView(t, lp);
            tabViews[i] = t;
        }
        View spacer = new View(this);
        header.addView(spacer, new LinearLayout.LayoutParams(0, 1, 1f));

        EditText search = new EditText(this);
        search.setHint("Search");
        search.setSingleLine(true);
        search.setTextColor(Color.WHITE);
        search.setHintTextColor(Color.parseColor("#6E7585"));
        search.setBackground(rounded(Color.parseColor("#222631"), 20));
        search.setPadding(dp(18), dp(8), dp(18), dp(8));
        search.addTextChangedListener(new TextWatcher() {
            public void beforeTextChanged(CharSequence s, int a, int b, int c) {}
            public void onTextChanged(CharSequence s, int a, int b, int c) {}
            public void afterTextChanged(Editable s) {
                query = s.toString();
                refresh();
            }
        });
        header.addView(search, new LinearLayout.LayoutParams(dp(260), ViewGroup.LayoutParams.WRAP_CONTENT));
        root.addView(header, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        // App grid
        GridView grid = new GridView(this);
        grid.setNumColumns(GridView.AUTO_FIT);
        grid.setColumnWidth(dp(120));
        grid.setStretchMode(GridView.STRETCH_COLUMN_WIDTH);
        grid.setVerticalSpacing(dp(14));
        grid.setSelector(android.R.color.transparent);
        grid.setPadding(0, dp(16), 0, dp(8));
        grid.setClipToPadding(false);
        adapter = new BaseAdapter() {
            public int getCount() { return shown.size(); }
            public Object getItem(int p) { return shown.get(p); }
            public long getItemId(int p) { return p; }
            public View getView(int p, View convert, ViewGroup parent) {
                App a = shown.get(p);
                LinearLayout cell = new LinearLayout(MainActivity.this);
                cell.setOrientation(LinearLayout.VERTICAL);
                cell.setGravity(Gravity.CENTER_HORIZONTAL);
                ImageView iv = new ImageView(MainActivity.this);
                iv.setImageDrawable(a.icon);
                cell.addView(iv, new LinearLayout.LayoutParams(dp(64), dp(64)));
                TextView tv = new TextView(MainActivity.this);
                boolean fav = getList("favs").contains(a.pkg);
                tv.setText((fav ? "\u2605 " : "") + a.label);
                tv.setTextColor(Color.WHITE);
                tv.setTextSize(13);
                tv.setGravity(Gravity.CENTER);
                tv.setMaxLines(2);
                tv.setEllipsize(TextUtils.TruncateAt.END);
                tv.setPadding(dp(4), dp(6), dp(4), 0);
                cell.addView(tv, new LinearLayout.LayoutParams(
                        ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
                return cell;
            }
        };
        grid.setAdapter(adapter);
        grid.setOnItemClickListener((parent, view, pos, id) -> launch(shown.get(pos)));
        grid.setOnItemLongClickListener((parent, view, pos, id) -> {
            toggleFav(shown.get(pos));
            return true;
        });
        root.addView(grid, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));

        // Bottom dock (pinned favorites)
        dock = new LinearLayout(this);
        dock.setOrientation(LinearLayout.HORIZONTAL);
        dock.setGravity(Gravity.CENTER);
        dock.setBackground(rounded(Color.parseColor("#222631"), 28));
        dock.setPadding(dp(16), dp(10), dp(16), dp(10));
        LinearLayout.LayoutParams dlp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        dlp.gravity = Gravity.CENTER_HORIZONTAL;
        root.addView(dock, dlp);

        setContentView(root);
    }

    @Override
    protected void onResume() {
        super.onResume();
        loadApps();
        refresh();
    }

    private void loadApps() {
        PackageManager pm = getPackageManager();
        all.clear();
        byPkg.clear();
        String[] categories = {Intent.CATEGORY_LAUNCHER, VR_CATEGORY};
        for (String cat : categories) {
            Intent i = new Intent(Intent.ACTION_MAIN);
            i.addCategory(cat);
            List<ResolveInfo> list = pm.queryIntentActivities(i, 0);
            for (ResolveInfo r : list) {
                String pkg = r.activityInfo.packageName;
                if (pkg.equals(getPackageName()) || byPkg.containsKey(pkg)) continue;
                App a = new App();
                a.pkg = pkg;
                a.label = String.valueOf(r.loadLabel(pm));
                a.cn = new ComponentName(pkg, r.activityInfo.name);
                a.icon = r.loadIcon(pm);
                all.add(a);
                byPkg.put(pkg, a);
            }
        }
        Collections.sort(all, (x, y) -> x.label.compareToIgnoreCase(y.label));
    }

    private void refresh() {
        shown.clear();
        String q = query.toLowerCase(Locale.ROOT).trim();
        if (tab.equals("recent")) {
            for (String p : getList("recent")) {
                App a = byPkg.get(p);
                if (a != null && matches(a, q)) shown.add(a);
            }
        } else {
            List<String> favs = getList("favs");
            for (App a : all) {
                if (tab.equals("fav") && !favs.contains(a.pkg)) continue;
                if (matches(a, q)) shown.add(a);
            }
        }
        for (int i = 0; i < 3; i++) {
            boolean sel = TAB_KEYS[i].equals(tab);
            tabViews[i].setTextColor(sel ? Color.WHITE : Color.parseColor("#8A90A0"));
            tabViews[i].setBackground(sel ? rounded(Color.parseColor("#2B2F3A"), 20) : null);
        }
        adapter.notifyDataSetChanged();
        rebuildDock();
    }

    private boolean matches(App a, String q) {
        return q.isEmpty() || a.label.toLowerCase(Locale.ROOT).contains(q);
    }

    private void rebuildDock() {
        dock.removeAllViews();
        int count = 0;
        for (String p : getList("favs")) {
            final App a = byPkg.get(p);
            if (a == null) continue;
            if (count >= 8) break;
            ImageView iv = new ImageView(this);
            iv.setImageDrawable(a.icon);
            iv.setOnClickListener(v -> launch(a));
            iv.setOnLongClickListener(v -> {
                toggleFav(a);
                return true;
            });
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(dp(56), dp(56));
            lp.leftMargin = dp(8);
            lp.rightMargin = dp(8);
            dock.addView(iv, lp);
            count++;
        }
        if (count == 0) {
            TextView hint = new TextView(this);
            hint.setText("Long-press an app to pin it here");
            hint.setTextColor(Color.parseColor("#8A90A0"));
            hint.setTextSize(14);
            dock.addView(hint);
        }
    }

    private void launch(App a) {
        try {
            Intent i = new Intent(Intent.ACTION_MAIN);
            i.setComponent(a.cn);
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(i);
            List<String> rec = getList("recent");
            rec.remove(a.pkg);
            rec.add(0, a.pkg);
            while (rec.size() > 12) rec.remove(rec.size() - 1);
            putList("recent", rec);
        } catch (Exception e) {
            Toast.makeText(this, "Couldn't open " + a.label, Toast.LENGTH_SHORT).show();
        }
    }

    private void toggleFav(App a) {
        List<String> favs = getList("favs");
        if (favs.contains(a.pkg)) {
            favs.remove(a.pkg);
            Toast.makeText(this, a.label + " unpinned", Toast.LENGTH_SHORT).show();
        } else {
            favs.add(a.pkg);
            Toast.makeText(this, a.label + " pinned", Toast.LENGTH_SHORT).show();
        }
        putList("favs", favs);
        refresh();
    }

    private List<String> getList(String key) {
        List<String> out = new ArrayList<>();
        String s = prefs.getString(key, "");
        if (s == null || s.isEmpty()) return out;
        for (String part : s.split(",")) {
            if (!part.isEmpty()) out.add(part);
        }
        return out;
    }

    private void putList(String key, List<String> list) {
        prefs.edit().putString(key, TextUtils.join(",", list)).apply();
    }
}
